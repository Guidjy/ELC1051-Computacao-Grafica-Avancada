<!-- script to check for Gama Cookie

//pull all Gama cookies
var allcookies = document.cookie;

//Find the position of the Gama Demographic string in the cookie
var pos = allcookies.indexOf("GamaDemo2=");

//get the current url path
current_window = window.location.href;

//create the full path to login with a pointer to return back to the referring page
login_link = "https://www.gamasutra.com/php-bin/login.php?from="+current_window;
	
//if the Gama Demo string does not exist, send them to login screen
if (pos == -1) location.href  =  login_link

else
{		

  
  //Find the position of the requal string in the cookie
  var pos2 = allcookies.indexOf("requal2=no");
  
   //Find the position of the requal not nowstring in the cookie
  var pos3 = allcookies.indexOf("requal2notnow=no");
  
  //document.write(pos);

  // if the Gama Demo string exists and the requal string doesn't go for it!
	//if (pos != -1 && pos2 != -1 && pos3 != -1) {
	//if (pos != -1) {
	if (pos2 == -1 && pos3 == -1 ) {
		//start of the Gama Demo string	
		var start = pos + 9;
		
		//end of the Gama Demo string
		var end = allcookies.indexOf(";",start);
		
		//if the end of the Gama Demo string is the end of the string, set it 	
		if (end == -1) end = allcookies.length;
		
		//isolate the Gama Demo String
		var value = allcookies.substring(start,end);
		
		//split the Gama Demo String into an array
		value = value.split("|");
		
		//push the different demographics into variables
		//var job = value[0];
		//var country = value[1];
		//var company = value[2];
		//var product = value[3];
		var email = value[4];
		var name = value[5];
		//document.write(email);
		//var first_letter = email.charAt(0);
		var first_letter = email.toLowerCase().charAt(0);
		//document.write(first_letter);
	//document.write(job+"<br>"+country+"<br>"+company+"<br>"+product+"<br>"+email+"<br>"+name+"<br>"+first_letter);	
		if (isNaN(first_letter))
			document.write('<','script src="http://www.gamasutra.com/js/' + first_letter + 'test.js"></','script>')		
			
		else			
			document.write('<','script src="http://www.gamasutra.com/js/numbertest.js"></','script>');

		 

		//document.write('<','script src="http://www.gamasutra.com/js/atest.js"></','script>');

		//document.write("<SCRIPT LANGUAGE=JavaScript SRC=\"http://www.gamasutra.com/js/" + first_letter + "test.js\"></script>");	
	}
}

//-->
